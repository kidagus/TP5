#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Por favor, proporciona un archivo de texto como argumento."
    exit 1
fi


if [ ! -f "$1" ]; then
    echo "El archivo no existe."
    exit 1
fi

lineas=$(wc -l < "$1")

palabras=$(wc -w < "$1")

caracteres=$(wc -m < "$1")

echo "Número de líneas: $lineas"
echo "Número de palabras: $palabras"
echo "Número de caracteres: $caracteres"


