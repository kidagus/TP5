#!/bin/bash


function eleccion_computadora {
    opciones=("piedra" "papel" "tijeras")
    indice=$(( RANDOM % 3 ))
    echo "${opciones[$indice]}"
}

function determinar_ganador {
    if [ "$1" == "$2" ]; then
        echo "¡Es un empate!"
    elif [ "$1" == "piedra" ] && [ "$2" == "tijeras" ]; then
        echo "¡Ganas! Piedra aplasta tijeras."
    elif [ "$1" == "papel" ] && [ "$2" == "piedra" ]; then
        echo "¡Ganas! Papel envuelve piedra."
    elif [ "$1" == "tijeras" ] && [ "$2" == "papel" ]; then
        echo "¡Ganas! Tijeras cortan papel."
    else
        echo "Pierdes. $2 vence a $1."
    fi
}

echo "¡Vamos a jugar a Piedra, Papel o Tijeras!"
read -p "Elige entre 'piedra', 'papel' o 'tijeras': " eleccion_usuario

while [[ "$eleccion_usuario" != "piedra" && "$eleccion_usuario" != "papel" && "$eleccion_usuario" != "tijeras" ]]; do
    echo "Entrada no válida. Por favor elige entre 'piedra', 'papel' o 'tijeras'."
    read -p "Elige entre 'piedra', 'papel' o 'tijeras': " eleccion_usuario
done

eleccion_pc=$(eleccion_computadora)
echo "La computadora ha elegido: $eleccion_pc"

determinar_ganador "$eleccion_usuario" "$eleccion_pc"
