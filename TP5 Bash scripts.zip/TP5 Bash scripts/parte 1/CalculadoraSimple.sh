

#!/bin/bash

function calcular {
    case $operacion in
        suma)
            resultado=$(echo "$num1 + $num2" | bc)
            echo "El resultado de sumar $num1 y $num2 es: $resultado"
            ;;
        resta)
            resultado=$(echo "$num1 - $num2" | bc)
            echo "El resultado de restar $num1 y $num2 es: $resultado"
            ;;
        multiplicacion)
            resultado=$(echo "$num1 * $num2" | bc)
            echo "El resultado de multiplicar $num1 y $num2 es: $resultado"
            ;;
        division)
            if [ "$num2" -eq 0 ]; then
                echo "Error: División por cero no permitida."
            else
                resultado=$(echo "scale=2; $num1 / $num2" | bc)
                echo "El resultado de dividir $num1 entre $num2 es: $resultado"
            fi
            ;;
        *)
            echo "Operación no válida. Por favor elige entre suma, resta, multiplicacion, division."
            ;;
    esac
}

read -p "Introduce el primer número: " num1
read -p "Introduce el segundo número: " num2

echo "Elige la operación que deseas realizar: suma, resta, multiplicacion, division"
read -p "Introduce la operación: " operacion

operacion=$(echo "$operacion" | tr '[:upper:]' '[:lower:]')

calcular



