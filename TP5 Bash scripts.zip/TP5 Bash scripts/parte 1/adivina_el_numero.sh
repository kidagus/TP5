#!/bin/bash

numero_secreto=$(( RANDOM % 100 + 1 ))

adivinanza=0

echo "¡Bienvenido al juego de Adivina el Número!"
echo "He generado un número entre 1 y 100. ¡Intenta adivinarlo!"

while [ $adivinanza -ne $numero_secreto ]; do
    read -p "Introduce tu adivinanza: " adivinanza

    if [ $adivinanza -lt $numero_secreto ]; then
        echo "Demasiado bajo. Intenta de nuevo."
    elif [ $adivinanza -gt $numero_secreto ]; then
        echo "Demasiado alto. Intenta de nuevo."
    else
        echo "¡Felicidades! Has adivinado el número."
    fi
done
