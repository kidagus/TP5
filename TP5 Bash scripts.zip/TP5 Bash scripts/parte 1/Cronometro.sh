#!/bin/bash

function mostrar_menu {
    echo "1. Iniciar cronómetro"
    echo "2. Detener cronómetro"
    echo "3. Reiniciar cronómetro"
    echo "4. Salir"
}

cronometro_iniciado=false
inicio=0
fin=0

while true; do
    mostrar_menu
    read -p "Elige una opción: " opcion

    case $opcion in
        1)
            if [ "$cronometro_iniciado" = false ]; then
                inicio=$(date +%s)
                cronometro_iniciado=true
                echo "Cronómetro iniciado."
            else
                echo "El cronómetro ya está en marcha."
            fi
            ;;
        2)
            if [ "$cronometro_iniciado" = true ]; then
                fin=$(date +%s)
                tiempo_transcurrido=$((fin - inicio))
                echo "Cronómetro detenido. Tiempo transcurrido: $tiempo_transcurrido segundos."
                cronometro_iniciado=false
            else
                echo "El cronómetro no está en marcha."
            fi
            ;;
        3)
            inicio=0
            fin=0
            cronometro_iniciado=false
            echo "Cronómetro reiniciado."
            ;;
        4)
            echo "Saliendo del cronómetro."
            exit 0
            ;;
        *)
            echo "Opción no válida. Por favor elige una opción del 1 al 4."
            ;;
    esac
done


