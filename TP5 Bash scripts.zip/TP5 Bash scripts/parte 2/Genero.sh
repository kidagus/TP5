#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Por favor, proporciona un nombre como argumento."
    exit 1
fi

NOMBRE=$1

RESPUESTA=$(curl -s "https://api.genderize.io/?name=$NOMBRE")

echo "Respuesta completa de la API:"
echo "$RESPUESTA"

if [ $? -ne 0 ]; then
    echo "Error al realizar la solicitud HTTP con curl."
    exit 1
fi

if echo "$RESPUESTA" | jq -e '.error' >/dev/null; then
    echo "Error: $(echo "$RESPUESTA" | jq -r '.error.message')"
    exit 1
fi

GENERO=$(echo "$RESPUESTA" | jq -r '.gender')
PROBABILIDAD=$(echo "$RESPUESTA" | jq -r '.probability')

if [ "$GENERO" != "null" ]; then
    echo "El género del nombre $NOMBRE es probablemente $GENERO con una probabilidad de $PROBABILIDAD."
else
    echo "No se pudo determinar el género del nombre $NOMBRE."
fi
