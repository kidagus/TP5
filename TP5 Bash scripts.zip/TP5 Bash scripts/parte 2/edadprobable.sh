#!/bin/bash

if [ $# -ne 1 ]; then
    echo "Uso: $0 NOMBRE"
    exit 1
fi

nombre="$1"

response=$(curl -s "https://api.agify.io/?name=${nombre}")

if [ $? -ne 0 ]; then
    echo "Error al conectar con la API de Agify."
    exit 1
fi

edad=$(echo "$response" | jq -r '.age')

if [ -n "$edad" ]; then
    echo "La edad probable para el nombre '$nombre' es: $edad años."
else
    echo "No se pudo obtener la edad probable para el nombre '$nombre'."
fi
