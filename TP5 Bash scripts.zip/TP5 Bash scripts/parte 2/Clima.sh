#!/bin/bash

API_KEY="7c51c22f5adc4e38be510705242906"

if [ $# -eq 0 ]; then
    echo "Por favor, proporciona el nombre de una ciudad como argumento."
    exit 1
fi

CIUDAD=$1

RESPUESTA=$(curl -s "http://api.weatherapi.com/v1/current.json?key=$API_KEY&q=$CIUDAD")

echo "Respuesta completa de la API:"
echo "$RESPUESTA"

if [ $? -ne 0 ]; then
    echo "Error al realizar la solicitud HTTP con curl."
    exit 1
fi

if echo "$RESPUESTA" | jq -e '.error' >/dev/null; then
    echo "Error: $(echo "$RESPUESTA" | jq -r '.error.message')"
    exit 1
fi

CIUDAD_NOMBRE=$(echo "$RESPUESTA" | jq -r '.location.name')
REGION=$(echo "$RESPUESTA" | jq -r '.location.region')
PAIS=$(echo "$RESPUESTA" | jq -r '.location.country')
TEMP_C=$(echo "$RESPUESTA" | jq -r '.current.temp_c')
CONDICION=$(echo "$RESPUESTA" | jq -r '.current.condition.text')

echo "El clima actual en $CIUDAD_NOMBRE, $REGION, $PAIS:"
echo "Temperatura: $TEMP_C°C"
echo "Condición: $CONDICION"

